"write.delim" <-
function(x,file="",row.names = FALSE, quote = FALSE, sep = "\t",...) write.table(x, file = file,row.names = row.names, quote = quote, sep = sep,...)
